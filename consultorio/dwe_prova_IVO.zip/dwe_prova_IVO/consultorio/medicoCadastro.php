<!DOCTYPE html>
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="estilo.css" type="text/css">
    </head>
    <body>
        <div id="menu">
            <form action="cadastroMedico.php" method="post">
                <label for="id_medico">Id :</label>
                <input type="number" name="id_medico" />
                <br />
                <label for="nome">Nome :</label>
                <input type="text" name="nome" />
                <br />
                <label for="crm">CRM :</label>
                <input type="text" name="crm" />
                <br />       

                <?php
                require_once('conexao.php');
                foreach ($dbh->query('SELECT *FROM especialidade WHERE id_especialidade ') as $linha) {
                    ?> 
                    Especialidade:
                    <select name="id_especialidade" multiple="multiple">
                        <?php
                        echo "<option value'id_especialidade'>{$linha['1']}</option>";
                        echo "<option value'id_especialidade'>{$linha['2']}</option>";
                        echo "<option value'id_especialidade'>{$linha['1']}</option>";
                    }
                    ?>       
                </select>                    
                <input type="submit" value="Cadastrar" />

            </form>
        </div>
    </body>
</html>