<?php
require_once('conexao.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Listar Paciente</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="estilo.css" type="text/css">
    </head>
    <body>         
        <div id="menu">
            <table>
                <thead>
                    <tr>
                        <th>id_paciente</th>
                        <th>Nome </th>
                        <th>cpf</th>
                        <th>data nascimento</th>
                        <th>sexo/th>
                    </tr> 
                </thead>
                <tbody>
                    <?php
                    foreach ($dbh->query('SELECT * FROM paciente') as $linha) {
                        echo '<tr>';
                        echo "<td>{$linha['id_paciente']}</td>";
                        echo "<td>{$linha['nome']}</td>";
                        echo "<td>{$linha['cpf']}</td>";
                        echo "<td>{$linha['data_nascimento']}</td>";
                        echo "<td>{$linha['sexo']}</td>";
                        echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>
            <br /><br />
        </div>
    </body>
</html>

