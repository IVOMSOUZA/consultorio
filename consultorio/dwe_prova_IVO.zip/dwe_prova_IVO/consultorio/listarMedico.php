<?php
require_once('conexao.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Listar Medico</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="estilo.css" type="text/css">
    </head>
    <body>
        <div id="menu">
            <table>
                <thead>
                    <tr>
                        <th>id_medico</th>
                        <th>Nome </th>
                        <th>CRM</th>
                        <th>Especialidade</th>

                        <!
                    </tr> 
                </thead>
                <tbody>
                    <?php
                    foreach ($dbh->query('SELECT * FROM medico') as $linha) {
                        echo '<tr>';
                        echo "<td>{$linha['id_medico']}</td>";
                        echo "<td>{$linha['nome']}</td>";
                        echo "<td>{$linha['crm']}</td>";
                        echo "<td>{$linha['id_especialidade']}</td>";



                        echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>
            <br /><br />
        </div>  
    </body>
</html>


