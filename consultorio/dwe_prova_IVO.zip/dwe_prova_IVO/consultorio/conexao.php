<?php

$dbh = new PDO('mysql:host=localhost;dbname=consultorio;charset=utf8', 'root', '');
